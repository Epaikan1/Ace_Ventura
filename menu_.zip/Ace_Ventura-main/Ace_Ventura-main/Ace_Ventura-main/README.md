Projet ayant pour but de réaliser un mini jeu python !
