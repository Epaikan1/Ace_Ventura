import subprocess
import pygame
import sys

# Initialisation de Pygame
pygame.init()

def lancer_menu():
    # Définir la taille de la fenêtre
    largeur_fenetre = 1920
    hauteur_fenetre = 1080
    fenetre = pygame.display.set_mode((largeur_fenetre, hauteur_fenetre))
    pygame.display.set_caption("Crédits de Jeu")

    # Charger le fond d'écran
    fond_credit = pygame.image.load('programme_menue/credits.png')
    fond_credit = pygame.transform.scale(fond_credit, (largeur_fenetre, hauteur_fenetre))

    # Charger l'image de "Back" et "Exit"
    image_back = pygame.image.load('programme_menue/back.png')
    image_exit = pygame.image.load('programme_menue/exit.png')

    # Positionner les images de "Back" et "Exit" à gauche en bas
    position_back = image_back.get_rect(center=(largeur_fenetre // 8, hauteur_fenetre - 200))
    position_exit = image_exit.get_rect(center=(largeur_fenetre // 4, hauteur_fenetre - 200))

    # Définir la police et la taille du texte
    police = pygame.font.Font(None, 50)

    # Position initiale du texte
    position_texte = hauteur_fenetre

    # Définir la vitesse de défilement des crédits
    vitesse_defilement = 2

    # Son pour les crédits
    son_credits = pygame.mixer.Sound('programme_menue/marginaux-feat-dinos.mp3')

    # Booléen pour savoir si les crédits sont en cours
    en_cours_de_credits = True

    # Hauteur maximale à partir de laquelle bloquer les crédits
    hauteur_maximale = hauteur_fenetre - 200  # Modifiez la hauteur selon vos besoins

    # Boucle principale
    running = True  # Ajout d'une variable de boucle
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if position_back.collidepoint(event.pos):
                    # Action lorsque le bouton "Back" est cliqué (lancer un fichier Python et quitter le programme)
                    subprocess.Popen(["python", "menu.py"])
                    pygame.quit()
                    sys.exit()
                if position_exit.collidepoint(event.pos):
                    # Action lorsque le bouton "Exit" est cliqué (quitter le programme)
                    pygame.quit()
                    sys.exit()

        # Afficher le fond d'écran
        fenetre.blit(fond_credit, (0, 0))

        # Afficher les images de "Back" et "Exit" en premier plan
        fenetre.blit(image_back, position_back)
        fenetre.blit(image_exit, position_exit)

        if en_cours_de_credits:
            # Définir la police et la taille du texte
            police = pygame.font.Font(None, 50)

            # Charger la liste de crédits (remplacez par vos crédits)
            credits = [
        "Liste 1 - Développement Classique",
"    Directeur du Jeu:",
"        Mael DEWULF",
"    Producteur:",
"        Thomas Lardé",
"    Lead Développeur:",
"        Edris Paikan",
"    Concepteur de Niveau:",
"        Athur Guilet",
"    Artiste Graphique:",
"        Maro Wague",
"    Testeur QA:",
"        Mael DEWULF",
"        Thomas Lardé",
"        Edris Paikan",
"        Athur Guilet",
"        Maro Wague",
"Liste 2 - Équipe Étendue",
"    Directeur du Jeu:",
"        Mael DEWULF",
"    Producteur Exécutif:",
"        Thomas Lardé",
"    Chef de Projet:",
"        Edris Paikan",
"    Lead Programmeur:",
"        Athur Guilet",
"    Lead Artiste:",
"        Maro Wague",
"    Designer Sonore:",
"        Mael DEWULF",
"        Thomas Lardé",
"        Edris Paikan",
"        Athur Guilet",
"        Maro Wague",
"    Scénariste:",
"        Mael DEWULF",
"        Thomas Lardé",
"        Edris Paikan",
"        Athur Guilet",
"        Maro Wague",
"    Testeur QA:",
"        Mael DEWULF",
"        Thomas Lardé",
"        Edris Paikan",
"        Athur Guilet",
"        Maro Wague",
"Liste 3 - Équipe Multidisciplinaire",
"    Directeur Créatif:",
"        Mael DEWULF",
"    Producteur Exécutif:",
"        Thomas Lardé",
"    Chef de Projet:",
"        Edris Paikan",
"    Game Designer:",
"        Athur Guilet",
"    Artiste 3D:",
"        Maro Wague",
"    Animateur:",
"        Mael DEWULF",
"        Thomas Lardé",
"        Edris Paikan",
"        Athur Guilet",
"        Maro Wague",
"    Compositeur Musical:",
"        Mael DEWULF",
"        Thomas Lardé",
"        Edris Paikan",
"        Athur Guilet",
"        Maro Wague",
"    Responsable QA (Assurance Qualité):",
"        Mael DEWULF",
"        Thomas Lardé",
"        Edris Paikan",
"        Athur Guilet",
"        Maro Wague",
"Liste 4 - Équipe Avancée",
"    Directeur de Technologie:",
"        Mael DEWULF",
"    Producteur Exécutif:",
"        Thomas Lardé",
"    Architecte Logiciel:",
"        Edris Paikan",
"    Ingénieur Gameplay:",
"        Athur Guilet",
"    Artiste Technique:",
"        Maro Wague",
"    Responsable Effets Visuels:",
"        Mael DEWULF",
"        Thomas Lardé",
"        Edris Paikan",
"        Athur Guilet",
"        Maro Wague",
"    Analyste de Données:",
"        Mael DEWULF",
"        Thomas Lardé",
"        Edris Paikan",
"        Athur Guilet",
"        Maro Wague",
"",
            ]

            # Afficher chaque ligne de crédit
            for i, ligne in enumerate(credits):
                texte_surface = police.render(ligne, True, (0, 0, 0))
                texte_rect = texte_surface.get_rect(center=(largeur_fenetre // 2, position_texte + i * 40))
                fenetre.blit(texte_surface, texte_rect)

                # Si la position du texte atteint la hauteur maximale, arrêtez le défilement
                if position_texte + i * 40 > hauteur_maximale:
                    en_cours_de_credits = False

            # Mettre à jour la position du texte pour simuler le défilement
            position_texte -= vitesse_defilement

        # Mettre à jour l'affichage
        pygame.display.flip()

        # Contrôler la vitesse de la boucle
        pygame.time.delay(10)  # Léger délai pour réduire la charge CPU

    pygame.quit()  # Fermer Pygame lorsque la boucle est terminée

# Appel de la fonction lancer_menu
if __name__ == "__main__":
    lancer_menu()
