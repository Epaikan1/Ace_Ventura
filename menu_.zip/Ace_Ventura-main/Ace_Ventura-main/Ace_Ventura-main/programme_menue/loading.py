import pygame
import sys
import random

pygame.init()

BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
WHITE = (255, 255, 255)

WIDTH, HEIGHT = 1920, 1080
window = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Barre de chargement")

total = 100
progress = 0
bar_width = 0

# Définir une plage pour la vitesse de chargement aléatoire
min_loading_time = 3
max_loading_time = 8

background_image_file = "programme_menue/loading.png"  # Remplacez par le nom de votre image

background_image = None
if background_image_file:
    background_image = pygame.image.load(background_image_file)
    background_image = pygame.transform.scale(background_image, (WIDTH, HEIGHT))

running = True
start_time = pygame.time.get_ticks()

# Générer une vitesse de chargement aléatoire au début
loading_time = random.uniform(min_loading_time, max_loading_time)

# Fonction de chargement
def chargement():
    global progress, bar_width, running  # Ajoutez running ici
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Calculer le temps écoulé
        current_time = pygame.time.get_ticks()
        elapsed_time = (current_time - start_time) / 1000  # Convertir en secondes

        # Calculer la progression en fonction du temps écoulé
        progress = min(int((elapsed_time / loading_time) * 100), 100)
        bar_width = int((progress / 100) * (WIDTH - 20))

        # Effacement de l'écran
        window.fill(BLACK)

        # Afficher l'image de fond (s'il y en a une)
        if background_image:
            window.blit(background_image, (0, 0))

        # Dessin de la barre de chargement avec contour
        pygame.draw.rect(window, WHITE, (WIDTH // 5 - 2, HEIGHT // 1.2 - 2, (WIDTH - 20) // 1.66 + 4, 44))  # Contour blanc
        pygame.draw.rect(window, GREEN, (WIDTH // 5, HEIGHT // 1.2, bar_width // 1.66, 40))

        # Affichage du pourcentage
        font = pygame.font.Font(None, 36)
        text = font.render(f"{progress}%", True, GREEN)
        text_rect = text.get_rect(center=(WIDTH // 2, HEIGHT // 1.25))
        window.blit(text, text_rect)

        pygame.display.flip()

        # Condition de sortie
        if progress >= 100:
            running = False

    pygame.quit()
    sys.exit()

# Appel de la fonction de chargement
chargement()
