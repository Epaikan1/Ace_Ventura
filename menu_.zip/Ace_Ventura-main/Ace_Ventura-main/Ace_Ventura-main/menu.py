import pygame
from pygame.locals import *
import subprocess
from programme_menue import credit
import sys
class Jeu:

    def __init__(self):
        # Initialisations
        pygame.init()
        # Obtenir la taille de l'écran
        self.largeur, self.hauteur = pygame.display.Info().current_w, pygame.display.Info().current_h
        self.lbouton = self.largeur // 5
        self.hbouton = self.hauteur // 10
        self.volume_son = 1.0
        # Fenêtre de jeu en plein écran
        self.fenetre = pygame.display.set_mode((self.largeur, self.hauteur), FULLSCREEN)
        pygame.display.set_caption("Ace Ventura")

        # Centre de l'écran
        self.centre_x, self.centre_y = self.largeur // 2, self.hauteur // 2

        # Chargement des images
        self.background_menu = pygame.image.load("assets/menu/background.png")
        self.background_menu = pygame.transform.scale(self.background_menu, (self.largeur, self.hauteur))

        # Chargement et positionnement des boutons
        self.assetsetting = pygame.image.load("assets/menu/setting.png")
        self.assetsetting = pygame.transform.scale(self.assetsetting, (int(self.largeur * 0.04), int(self.largeur * 0.04)))
        self.assetsetting_orig = self.assetsetting.copy()
        self.assetsetting_rect = self.assetsetting.get_rect(center=(self.centre_x - int(self.largeur * 0.17), self.centre_y + int(self.hauteur * 0.14)))

        self.assetinfo = pygame.image.load("assets/menu/info.png")
        self.assetinfo = pygame.transform.scale(self.assetinfo, (int(self.largeur * 0.04), int(self.largeur * 0.04)))
        self.assetinfo_orig = self.assetinfo.copy()
        self.assetinfo_rect = self.assetinfo.get_rect(center=(self.centre_x - int(self.largeur * 0.13), self.centre_y + int(self.hauteur * 0.14)))

        self.assetmusic_on = pygame.image.load("assets/menu/music_on.png")
        self.assetmusic_on = pygame.transform.scale(self.assetmusic_on, (int(self.largeur * 0.04), int(self.largeur * 0.04)))
        self.assetmusic_off = pygame.image.load("assets/menu/music_off.png")
        self.assetmusic_off = pygame.transform.scale(self.assetmusic_off, (int(self.largeur * 0.04), int(self.largeur * 0.04)))
        self.assetmusic_on_orig = self.assetmusic_on.copy()
        self.assetmusic_off_orig = self.assetmusic_off.copy()
        self.assetmusic_rect = self.assetmusic_on.get_rect(center=(self.centre_x - int(self.largeur * 0.09), self.centre_y + int(self.hauteur * 0.14)))

        self.assetcredits = pygame.image.load("assets/menu/credits.png")
        self.assetcredits = pygame.transform.scale(self.assetcredits, (int(self.lbouton * 0.9), self.hbouton))
        self.assetcredits_orig = self.assetcredits.copy()
        self.assetcredits_rect = self.assetcredits.get_rect(center=(self.centre_x + int(self.largeur * 0.09), self.centre_y + int(self.hauteur * 0.14)))

        self.assetplay = pygame.image.load("assets/menu/play.png")
        self.assetplay = pygame.transform.scale(self.assetplay, (int(self.lbouton * 1.2), self.hbouton))
        self.assetplay_orig = self.assetplay.copy()
        self.assetplay_rect = self.assetplay.get_rect(center=(self.centre_x, self.centre_y + 2 * (self.hbouton + 30)))

        self.assetexit = pygame.image.load("assets/menu/exit.png")
        self.assetexit = pygame.transform.scale(self.assetexit, (int(self.lbouton * 1.2), self.hbouton))
        self.assetexit_orig = self.assetexit.copy()
        self.assetexit_rect = self.assetexit.get_rect(center=(self.centre_x, self.centre_y + 3 * (self.hbouton + 30)))

        # Écran de chargement
        self.loading_screen = pygame.image.load("assets/menu/loading_screen.png")
        self.loading_screen = pygame.transform.scale(self.loading_screen, (self.largeur, self.hauteur))

        self.etat = "menu"
        self.loading = False

        # Configuration de la musique
        self.musique_joue = True
        pygame.mixer.init()
        pygame.mixer.music.load('assets/music/jump_sound.mp3')
        pygame.mixer.music.play(-1)

        # Chargement de l'image en grand
        self.image_info = pygame.image.load("assets/menu/regle.png")
        self.image_info = pygame.transform.scale(self.image_info, (self.largeur, self.hauteur))

    def afficher_menu(self):
        self.fenetre.blit(self.background_menu, (0, 0))
        self.fenetre.blit(self.assetsetting, self.assetsetting_rect)
        self.fenetre.blit(self.assetinfo, self.assetinfo_rect)
        if self.musique_joue:
            self.fenetre.blit(self.assetmusic_on, self.assetmusic_rect)
        else:
            self.fenetre.blit(self.assetmusic_off, self.assetmusic_rect)
        self.fenetre.blit(self.assetcredits, self.assetcredits_rect)
        self.fenetre.blit(self.assetplay, self.assetplay_rect)
        self.fenetre.blit(self.assetexit, self.assetexit_rect)

    def afficher_loading_screen(self):
        self.fenetre.blit(self.loading_screen, (0, 0))

    def toggle_musique(self):
        if self.musique_joue:
            pygame.mixer.music.pause()
            self.musique_joue = False
        else:
            pygame.mixer.music.unpause()
            self.musique_joue = True

    def afficher_credits(self):
        credits = [
        "Liste 1 - Développement Classique",
        "    Directeur du Jeu:",
        "        Mael DEWULF",
        # Ajoutez le reste de vos crédits ici
        ]

    # Définissez la police et la taille du texte
    police = pygame.font.Font(None, 36)

    # Position initiale du texte
    position_texte = self.hauteur

    # Définissez la vitesse de défilement des crédits
    vitesse_defilement = 2

    en_cours_de_credits = True

    # Hauteur maximale à partir de laquelle bloquer les crédits
    hauteur_maximale = self.hauteur - 200  # Modifiez la hauteur selon vos besoins

    while en_cours_de_credits:
        for evenement in pygame.event.get():
            if evenement.type == QUIT:
                pygame.quit()
                sys.exit()

        # Afficher le fond d'écran du menu (ou tout autre fond que vous avez)
            self.fenetre.blit(self.background_menu, (0, 0))

        # Afficher les crédits
        for i, ligne in enumerate(credits):
            texte_surface = police.render(ligne, True, (0, 0, 0))
            texte_rect = texte_surface.get_rect(center=(self.largeur // 2, position_texte + i * 40))
            self.fenetre.blit(texte_surface, texte_rect)

            # Si la position du texte atteint la hauteur maximale, arrêtez le défilement
            if position_texte + i * 40 > hauteur_maximale:
                en_cours_de_credits = False

        # Mettre à jour la position du texte pour simuler le défilement
        position_texte -= vitesse_defilement

        pygame.display.flip()


    def afficher_popup_setting(self):
        # Créer une surface pour le pop-up des paramètres
        popup_width = 400
        popup_height = 300
        popup_x = (self.largeur - popup_width) // 2
        popup_y = (self.hauteur - popup_height) // 2
        popup_surface = pygame.Surface((popup_width, popup_height))
        popup_surface.fill((255, 255, 255))  # Remplir la surface avec une couleur de fond

        # Dessiner un cadre autour du pop-up
        pygame.draw.rect(popup_surface, (0, 0, 0), (0, 0, popup_width, popup_height), 2)

        # Bouton de fermeture du pop-up
        close_button = pygame.image.load("assets/menu/close_button.png")
        close_button = pygame.transform.scale(close_button, (30, 30))
        close_button_rect = close_button.get_rect(topright=(popup_width - 10, 10))
        popup_surface.blit(close_button, close_button_rect)

        # Boutons "+" et "-"
        plus_button = pygame.image.load("assets/menu/plus_button.png")
        plus_button = pygame.transform.scale(plus_button, (30, 30))
        plus_button_rect = plus_button.get_rect(midleft=(50, popup_height // 2))
        popup_surface.blit(plus_button, plus_button_rect)

        minus_button = pygame.image.load("assets/menu/plus_button.png")  # Assurez-vous d'avoir cette image
        minus_button = pygame.transform.scale(minus_button, (30, 30))
        minus_button_rect = minus_button.get_rect(midleft=(50, popup_height // 2 + 50))
        popup_surface.blit(minus_button, minus_button_rect)

        # Afficher le volume actuel
        volume_label = pygame.font.Font(None, 36).render(f"Volume: {int(self.volume_son * 100)}%", True, (0, 0, 0))
        popup_surface.blit(volume_label, (100, 50))

        # Blitter la surface du pop-up sur la fenêtre principale
        self.fenetre.blit(popup_surface, (popup_x, popup_y))


        # Afficher le volume actuel
        volume_label = pygame.font.Font(None, 36).render(f"Volume: {int(self.volume_son * 100)}%", True, (0, 0, 0))
        popup_surface.blit(volume_label, (100, 50))

        # Blitter la surface du pop-up sur la fenêtre principale
        self.fenetre.blit(popup_surface, (popup_x, popup_y))


        # Afficher le volume actuel
        volume_label = pygame.font.Font(None, 36).render(f"Volume: {int(self.volume_son * 100)}%", True, (0, 0, 0))
        popup_surface.blit(volume_label, (popup_x + 100, popup_y + 50))

        self.fenetre.blit(popup_surface, (popup_x, popup_y))

    def afficher_image_info(self):
        # Créer une nouvelle fenêtre pour afficher l'image en grand
        image_info_fenetre = pygame.display.set_mode(self.image_info.get_size())
        image_info_fenetre.blit(self.image_info, (0, 0))
        pygame.display.flip()

        en_attente = True
        while en_attente:
            for evenement in pygame.event.get():
                if evenement.type == QUIT:
                    en_attente = False


    def zoom_image(self, image, rect, scale):
        image = pygame.transform.scale(image, (int(rect.width * scale), int(rect.height * scale)))
        return image

    def run(self):
        running = True
        while running:
            mouse_pos = pygame.mouse.get_pos()
            for evenement in pygame.event.get():
                if evenement.type == QUIT:
                    running = False
                elif evenement.type == MOUSEBUTTONDOWN:
                    if self.assetplay_rect.collidepoint(evenement.pos) and not self.loading:
                        self.loading = True
                        # Lancer le programme loading.py
                        subprocess.Popen(["python", "programme_menue/loading.py"])
                    elif self.assetmusic_rect.collidepoint(evenement.pos):
                        self.toggle_musique()
                    elif self.assetsetting_rect.collidepoint(evenement.pos):
                        self.afficher_popup_setting()  # Afficher le pop-up des paramètres
                    elif self.assetinfo_rect.collidepoint(evenement.pos):
                        self.afficher_image_info()  # Afficher l'image en grand lorsque l'icône "Info" est cliquée
                    elif self.assetcredits_rect.collidepoint(evenement.pos):
                        self.afficher_credits()
                    elif self.assetexit_rect.collidepoint(evenement.pos):
                        running = False

            if self.loading:
                self.afficher_loading_screen()
                pygame.display.flip()
                # Simulation d'un chargement (attente de 0 secondes ici, remplacez par le chargement réel de votre jeu)
                pygame.time.delay(0)
                self.loading = False
                self.etat = "play"  # Passer à l'écran de jeu après le chargement

            elif self.etat == "menu":
                self.afficher_menu()
                # Gérer le zoom sur les boutons
                if self.assetplay_rect.collidepoint(mouse_pos):
                    self.assetplay = self.zoom_image(self.assetplay_orig, self.assetplay_rect, 1.1)
                else:
                    self.assetplay = self.assetplay_orig.copy()

                if self.assetsetting_rect.collidepoint(mouse_pos):
                    self.assetsetting = self.zoom_image(self.assetsetting_orig, self.assetsetting_rect, 1.1)
                else:
                    self.assetsetting = self.assetsetting_orig.copy()

                if self.assetinfo_rect.collidepoint(mouse_pos):
                    self.assetinfo = self.zoom_image(self.assetinfo_orig, self.assetinfo_rect, 1.1)
                else:
                    self.assetinfo = self.assetinfo_orig.copy()

                if self.assetcredits_rect.collidepoint(mouse_pos):
                    self.assetcredits = self.zoom_image(self.assetcredits_orig, self.assetcredits_rect, 1.1)
                else:
                    self.assetcredits = self.assetcredits_orig.copy()

                if self.assetmusic_rect.collidepoint(mouse_pos):
                    if self.musique_joue:
                        self.assetmusic_on = self.zoom_image(self.assetmusic_on_orig, self.assetmusic_rect, 1.1)
                    else:
                        self.assetmusic_off = self.zoom_image(self.assetmusic_off_orig, self.assetmusic_rect, 1.1)
                else:
                    if self.musique_joue:
                        self.assetmusic_on = self.assetmusic_on_orig.copy()
                    else:
                        self.assetmusic_off = self.assetmusic_off_orig.copy()

            pygame.display.flip()

        pygame.quit()

# Création et exécution du jeu
jeu = Jeu()
jeu.run()
